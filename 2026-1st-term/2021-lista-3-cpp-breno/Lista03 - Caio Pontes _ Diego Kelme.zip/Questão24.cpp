#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	double temp, fusao, ebulicao;
	temp = 0;
	fusao = -94.6;
	ebulicao = 56.1;
	printf("\n\n> Este programa lhe dir� com base no valor da temperatura se, ao n�vel do mar,");
	printf("a acetona est� em temperatura inferior ao ponto de fus�o ou em temperatura superior ao ponto de ebuli��o! :)");
	printf("\n\n Por favor usu�rio, digite a temperatura em graus Celsius: ");
	scanf("%lf", &temp);
	if(temp < fusao)
		printf("\n> A acetona est� em temperatura inferior ao ponto de fus�o! :)");
	if(temp > ebulicao)
		printf("\n> A acetona est� em temperatura superior ao ponto de ebuli��o! :)");
	if(temp > fusao && temp < ebulicao)
		printf("\n> A acetona n�o est� nem no ponto de ebuli��o e nem no ponto de fus�o! :)");
	if(temp == fusao)
		printf("\n> A acetona est� exatamente no ponto de fus�o! :)");
	if(temp == ebulicao)
		printf("\n> A acetona est� exatamente no ponto de ebuli��o! :)");

	printf("\n\n> Agrade�o a sua pref�rencia em utilizar este programa, disponha! ;-)\n");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
}

