#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	double volume = 0.0, raio = 0.0, altura = 0.0, volTOTAL;
	printf("Este programa determina o volume de �gua de um reservat�rio em formato de cilindro onde apenas 80% est� cheio");
	printf("\n\nDigite a altura do reservat�rio em metros: ");
	scanf("%lf", &altura);
	printf("\n\nDigite o raio da base do reservat�rio em metros: ");
	scanf("%lf", &raio);
	volume = (3.14 * (raio * raio)) * altura;
	volTOTAL = ((volume/100) * 80)* 1000;
	if(volTOTAL > 0){
		printf("\n\nO volume de �gua no reservat�rio � de %.2f litros\n\n", volTOTAL);
	}
	if(volTOTAL <= 0){
		printf("\n\ndigite valores v�lidos!");
	}
	printf("\n\nObrigado por ultilizar este programa!\n\n");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
}
	
