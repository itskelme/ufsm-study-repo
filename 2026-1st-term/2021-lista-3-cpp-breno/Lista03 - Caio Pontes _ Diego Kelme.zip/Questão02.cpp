#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	float raio, areaCirculo = 0;
	printf ("\n\nEste programa determina a �rea de um c�rculo qualquer!");
	printf ("\n\nDigite o valor do raio do c�rculo (m): ");
	scanf ("%f", &raio);
	areaCirculo = 3.1416 * (raio * raio);
	printf ("\n\nA �rea do c�rculo � de %.2f m�! :)", areaCirculo);	
	printf ("\n\nObrigado por utilizar nosso programa! :)\n\n");	
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;	
}

