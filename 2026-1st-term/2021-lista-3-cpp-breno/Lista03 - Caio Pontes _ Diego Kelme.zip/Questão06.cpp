#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void) 
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	int i, soma = 0;
	printf ("\n\nEste programa imprime e soma os n�meros inteiros m�ltiplos de 7 entre 100 e 300!");
	printf ("\n\nN�meros inteiros m�ltiplos de 7 entre 100 e 300: ");
	for (i = 100; i <= 300; i++) {
		if (i%7 == 0) {
			printf ("  %d", i);
			soma += i; //soma = soma + i
		}
	}
	printf ("\n\nO valor soma dos n�meros inteiros m�ltiplos de 7 entre 100 e 300 � %d! :)", soma);
	printf ("\n\nObrigado por utilizar nosso programa! :)\n\n");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
}
