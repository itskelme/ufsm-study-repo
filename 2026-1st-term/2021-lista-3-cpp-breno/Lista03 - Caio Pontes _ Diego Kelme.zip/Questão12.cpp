#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	int protons1, neutrons1, massa1, protons2, neutrons2, massa2, protons3, neutrons3, massa3, vazio;
	printf("\n> Caro usu�rio, este programa lhe determinar� dentre tr�s elementos quais s�o is�topos, is�tonos ou isob�ros entre si!");
	
	printf("\n\n>> Por favor usu�rio, digite o n�mero at�mico do primeiro elemento: ");
	scanf("%d", &protons1);
	printf("\n\n>> Por favor usu�rio, digite o n�mero de massa do primeiro elemento: ");
	scanf("%d", &massa1);
	printf("\n\n>> Por favor usu�rio, digite o n�mero at�mico do segundo elemento: ");
	scanf("%d", &protons2);
	printf("\n\n>> Por favor usu�rio, digite o n�mero de massa do segundo elemento: ");
	scanf("%d", &massa2);
	printf("\n\n>> Por favor usu�rio, digite o n�mero at�mico do terceiro elemento: ");
	scanf("%d", &protons3);
	printf("\n\n>> Por favor usu�rio, digite o n�mero de massa do terceiro elemento: ");
	scanf("%d", &massa3);
	
	neutrons1 = massa1 - protons1;
	neutrons2 = massa2 - protons2;
	neutrons3 = massa3 - protons3;
	
	if(massa1 == massa2){
		printf("\n\n> O primeiro e o segundo elemento s�o is�baros entre si!");
	}
	if(massa2 == massa3){
		printf("\n\n> O segundo e o teceiro elemento s�o is�baros entre si!");
	}
	if(massa3 == massa1){
		printf("\n\n> O terceiro e o primeiro elemento s�o is�baros entre si!");
	}
	if(neutrons1 == neutrons2){
		printf("\n\n> O primeiro e o segundo elemento s�o is�tonos entre si!");
	}
	if(neutrons2 == neutrons3){
		printf("\n\n> O segundo e o teceiro elemento s�o is�tonos entre si!");
	}
	if(neutrons3 == neutrons1){
		printf("\n\n> O terceiro e o primeiro elemento s�o is�tonos entre si!");
	}
	if(protons1 == protons2){
		printf("\n\n> O primeiro e o segundo elemento s�o is�topos entre si!");
	}
	if(protons2 == protons3){
		printf("\n\n> O segundo e o teceiro elemento s�o is�topos entre si!");
	}
	if(protons3 == protons1){
		printf("\n\n> O terceiro e o primeiro elemento s�o is�topos entre si!");
	}
	if(massa1 != massa2 && massa2 != massa3 && massa3 != massa1){
		printf("\n\nNenhum dos tr�s elementos n�o s�o is�baros entre si");
	}
	if(neutrons1 != neutrons2 && neutrons2 != neutrons3 && neutrons3 != neutrons1){
		printf("\n\nNenhum dos tr�s elementos n�o s�o is�tonos entre si");
	}
	if(protons1 != protons2 && protons2 != protons3 && protons3 != protons1){
		printf("\n\nNenhum dos tr�s elementos n�o s�o is�topos entre si");
	}
	printf("\n\n> Agrade�o a sua pref�rencia em utilizar este programa, disponha! ;-)\n");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
	
}
	
