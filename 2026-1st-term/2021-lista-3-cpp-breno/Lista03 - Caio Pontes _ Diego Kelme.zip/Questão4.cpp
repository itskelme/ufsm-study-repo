#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	int n, maior, menor, par, impar, i, atual, anterior, op, div;
	double valor, soma, media;
	soma = 0.0;
	media = 0.0;
	n = 0;
	maior = -2147483647;
	menor = 2147483647;
	i = 1 ;
	atual = 0 ;
	anterior = 0 ;
	op = 0;
	div = 0;
	par = 0;
	impar = 0;
	par = 0;
	printf("\n> Este programa basicamente ir� ler 'n' n�meros inteiros n�o negativos e determinar� qual � o maior, o menor, ");
	printf("\na quantidade de pares, a quantidade de �mpares e a m�dia de todos os n�meros!");
	printf("\n\n>> Por favor usu�rio, voc� dever� digitar um valor (inteiro e n�o negativo) para quantidade de n�meros que quer determinar: ");
	scanf("%d", &n);
	
	while(i <= n){
		printf("\n\nDigite o valor do %d� n�mero: ", i);
		scanf("%lf", &valor);
		soma = soma + valor;
		if(valor > maior){
			maior = valor;
		}
		if(valor < menor){
		menor = valor;
		}
		if(valor == 0)
		printf("\n\nO n�mero � 0!");
		if( valor != 0){
			div = (valor / 2);
		
			if((div * 2) == valor){
			par = par + 1;
			}
			if((div * 2) != valor){
			impar = impar + 1;
			}
		}
		i++;
	}
	media = soma/n;
	
	printf("\n\nS�o(�) %d n�mero(s) par(es)!", par);
	printf("\n\nS�o(�) %d n�mero(s) �mpar(es)!", impar);
	printf("\n\nA m�dia do(s) %d n�mero(s) � %.2f!", n, media);
	printf("\n\nO maior do(s) %d n�mero(s) � %d!", n, maior);
	printf("\n\nO menor do(s) %d n�mero(s) � %d!", n, menor);
	
	printf("\n\nObrigado por utilizar nosso programa!\n\n");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
}
	
