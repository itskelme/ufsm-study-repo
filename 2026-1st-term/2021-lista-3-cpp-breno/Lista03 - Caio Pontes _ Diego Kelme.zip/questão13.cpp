#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main (void)
{
	system ("cls");
	setlocale (LC_ALL, "Portuguese");
	int num, valor , divisores , vazio;
	valor = 1;
	divisores = 0;
	printf("Este programa determina se um n�mero inteiro � primo");
	printf("\n\nEscreva o n�mero: ");
	scanf("%d", &num);
	if (num > 0){
		while(valor <= num){
			if(num % valor == 0){
				divisores++ ;
			}
			valor++ ;

		}
		if(divisores == 2){
			printf("\n\nO n�mero %d � primo", num);
		}
		else if(divisores > 2){
			printf("\n\n O n�mero %d n�o � primo", num);
		}

	}
	else if(divisores < 2){
		printf("\n\nO n�mero � negativo ou igual a zero!");
	}
	printf("\n\nObrigado por ultilizar este programa!");
	#ifdef WIN32
	system ("pause");
	#endif
	return 0;
}
